

export default async function Page() {
  return (
    <div>
      hello page music
    </div>
  )
}