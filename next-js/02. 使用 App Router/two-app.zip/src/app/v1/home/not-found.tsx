export default function NotFound() {
  return (
    <div>
      home not-found
    </div>
  )
}