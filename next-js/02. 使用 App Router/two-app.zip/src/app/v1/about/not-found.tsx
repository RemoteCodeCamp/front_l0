export default function NotFound() {
  return (
    <div>
      about not-found
    </div>
  )
}