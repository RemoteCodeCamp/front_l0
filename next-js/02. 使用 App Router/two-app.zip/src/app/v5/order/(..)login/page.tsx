export default function Page() {
  return (
    <div>
      拦截的 login page
    </div>
  )
}