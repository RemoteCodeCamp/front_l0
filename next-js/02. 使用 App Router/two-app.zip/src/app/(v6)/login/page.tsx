import Login from "@/components/Login"
export default function Page() {
  return (
    <div>
      <Login />
    </div>
  )
}