
export default function NotFound() {
  return (
    <div>
      custom global not-found
    </div>
  )
}