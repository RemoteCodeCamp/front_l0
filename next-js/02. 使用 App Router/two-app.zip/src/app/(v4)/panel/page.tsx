export default function Page() {
  return (
    <div>
      hello panel page
    </div>
  )
}