export default function Loading() {
  return (
    <div>
      card loading ...
    </div>
  )
}