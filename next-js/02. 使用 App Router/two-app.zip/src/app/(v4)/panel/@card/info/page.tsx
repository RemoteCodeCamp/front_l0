
export default function Page() {
  return (
    <div>
      hello info page
    </div>
  )
}