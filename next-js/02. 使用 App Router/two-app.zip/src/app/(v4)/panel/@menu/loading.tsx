export default function Loading() {
  return (
    <div>
      menu loading ...
    </div>
  )
}