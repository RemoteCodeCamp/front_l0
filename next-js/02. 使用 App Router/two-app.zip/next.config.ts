import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  /* async redirects() {
    return [
      {
        source: '/setting',
        destination: '/login',
        permanent: true   // true永久重定向，false临时重定向
      }
    ]
  } */
};

export default nextConfig;
